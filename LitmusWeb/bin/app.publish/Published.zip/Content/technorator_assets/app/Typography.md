## Font Sizes:

- h1 -> 60px
- h2 -> 40px
- h3 -> 34px
- h4 -> 28px
- h5 -> 22px
- h6 -> 18px