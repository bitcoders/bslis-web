		</main>

		<footer id="cnt_footer">
			<div class="container">
				<div class="footer-inner">
					
					<div class="copyright-container">
						<p>&copy; Copyright <?php echo date('Y'); ?> <strong>Secugopro.com</strong></p>
					</div>
					<div class="footer-nav">
						<ul class="list-inline-float">
							<li><a href="#">Privacy</a></li>
							<li><a href="#">Terms of Service</a></li>
							<li><a href="#">Contact Us</a></li>
						</ul>
					</div>

				</div>
			</div>
		</footer>

		<?php require_once dirname(__FILE__) . '/_user-actions-modal.php'; ?>
		<?php require_once dirname(__FILE__) . '/_user-bookings-modal.php'; ?>

		<!-- Preloader Script -->
		<script src="assets/js/preloader.js" type="text/javascript"></script>

		<!-- Functions Script -->
		<script src="assets/js/functions.js" type="text/javascript"></script>

		<!-- App Script -->
		<script src="assets/js/app.js" type="text/javascript"></script>

	</body>
</html>