﻿
function openInNewWindowWithSettings() {
    window.open('/home/login', target = '_blank', width = '1000px', height = '800px');
    //                  //options:
    //                    //fullscreen = 'yes',
    //                    //height = '800px',
    //                    //left = '20px',
    //                    //location = 'no', //address field
    //                    //menubar = 'no',
    //                    //resizeable = 'yes',
    //                    //scrollbars = 'yes',
    //                    //status = 'yes', //status bar
    //                    //titlebar = 'yes',
    //                    //toolbar = 'yes',
    //                    //top = '20px',
    //                    //width = '1000px'

} (jQuery)